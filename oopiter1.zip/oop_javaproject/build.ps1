Write-Host "=== Course Registration System Build Script ===" -ForegroundColor Cyan
Write-Host "Group: [Replace with your group number]"
Write-Host "Iteration: 1"
Write-Host "Project Location: C:\oop_javaproject\oop_javap_test"
Write-Host ""

# Set classpath for Windows
$env:CLASSPATH = "lib\gson-2.8.9.jar;lib\junit-platform-console-standalone-1.8.2.jar"

# Clean previous builds
Write-Host "Cleaning previous builds..." -ForegroundColor Yellow
if (Test-Path "build") {
    Remove-Item "build" -Recurse -Force
}
New-Item -ItemType Directory -Path "build" -Force | Out-Null
New-Item -ItemType Directory -Path "build\classes" -Force | Out-Null
New-Item -ItemType Directory -Path "build\test-classes" -Force | Out-Null

# Compile main source files
Write-Host "Compiling main source files..." -ForegroundColor Yellow
$compileMain = javac -cp $env:CLASSPATH -d "build\classes" src\*.java
if ($LASTEXITCODE -eq 0) {
    Write-Host "✓ Main compilation successful" -ForegroundColor Green
} else {
    Write-Host "✗ Main compilation failed" -ForegroundColor Red
    exit 1
}

# Compile test files
Write-Host "Compiling test files..." -ForegroundColor Yellow
$compileTest = javac -cp "$env:CLASSPATH;build\classes" -d "build\test-classes" test\*.java
if ($LASTEXITCODE -eq 0) {
    Write-Host "✓ Test compilation successful" -ForegroundColor Green
} else {
    Write-Host "✗ Test compilation failed" -ForegroundColor Red
    exit 1
}

# Generate sample data
Write-Host "Generating sample data..." -ForegroundColor Yellow
$generateData = java -cp "$env:CLASSPATH;build\classes" DataGenerator
if ($LASTEXITCODE -eq 0) {
    Write-Host "✓ Sample data generation successful" -ForegroundColor Green
} else {
    Write-Host "✗ Sample data generation failed" -ForegroundColor Red
    exit 1
}

# Run unit tests
Write-Host "Running unit tests..." -ForegroundColor Yellow
java -jar "lib\junit-platform-console-standalone-1.8.2.jar" --class-path "build\classes;build\test-classes;$env:CLASSPATH" --scan-classpath

Write-Host ""
Write-Host "=== Build Summary ===" -ForegroundColor Cyan
Write-Host "✓ Main classes compiled" -ForegroundColor Green
Write-Host "✓ Test classes compiled" -ForegroundColor Green
Write-Host "✓ Sample data generated" -ForegroundColor Green
Write-Host "✓ Unit tests executed" -ForegroundColor Green
Write-Host ""
Write-Host "To run the application:" -ForegroundColor Yellow
Write-Host "java -cp `"$env:CLASSPATH;build\classes`" CourseRegistrationApp" -ForegroundColor White